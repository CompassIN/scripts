x=$(date -d "+1 days" +"%d")
echo $(date +'%m/%d/%Y 00:00:00 %m/'$x'/%Y 21:00:00 %m/%d/%Y %H:%M:%S')
#cat abc
