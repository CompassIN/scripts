/*-----------------------------------------------------------------------------
    Name: san
    Recorded By: cavisson
    Date of recording: 06/12/2019 01:22:03
    Flow details:
    Build details: 4.1.14 (build# 126)
    Modification History:
-----------------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ns_string.h"

void san()
{
    ns_start_transaction("index_html_2");
    ns_web_url ("index_html_2",
        "URL=http://66.220.31.131:9020/tours/index.html",
        "HEADER=Accept-Language:en-in",
        "HEADER=Upgrade-Insecure-Requests:1",
        "PreSnapshot=webpage_1560325606036.png",
        "Snapshot=webpage_1560325615497.png",
        INLINE_URLS,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/banner_animated.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/sun_swede.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/login.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/images/banner_merctur.jpg", "HEADER=Accept-Language:en-in", END_INLINE
    );

    ns_end_transaction("index_html_2", NS_AUTO_STATUS);
    ns_page_think_time(68.491);

    //Page Auto splitted for Image Link 'Login' Clicked by User
    ns_start_transaction("login_2");
    ns_web_url ("login_2",
        "URL=http://66.220.31.131:9020/cgi-bin/login?userSession=75893.0884568651DQADHfApHDHfcDtccpfAttcf&username=sdsd&password=sasas&login.x=30&login.y=9&login=Login&JSFormSubmit=off",
        "HEADER=Upgrade-Insecure-Requests:1",
        "HEADER=Accept-Language:en-in",
        "PreSnapshot=webpage_1560325683714.png",
        "Snapshot=webpage_1560325694533.png",
        INLINE_URLS,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/banner_animated.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/sun_swede.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/flights.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/home.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/signoff.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/images/banner_merctur.jpg", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/vep/images/velocigen.gif", "HEADER=Accept-Language:en-in", END_INLINE
    );

    ns_end_transaction("login_2", NS_AUTO_STATUS);
    ns_page_think_time(7.453);

    ns_start_transaction("reservation_2");
    ns_web_url ("reservation_2",
        "URL=http://66.220.31.131:9020/cgi-bin/reservation",
        "HEADER=Upgrade-Insecure-Requests:1",
        "HEADER=Accept-Language:en-in",
        "PreSnapshot=webpage_1560325701903.png",
        "Snapshot=webpage_1560325711336.png"
    );

    ns_end_transaction("reservation_2", NS_AUTO_STATUS);
    ns_page_think_time(0.156);

    //Page Auto splitted for Image Link 'Search Flights Button' Clicked by User
    ns_start_transaction("banner_animated_gif");
    ns_web_url ("banner_animated_gif",
        "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/banner_animated.gif",
        "HEADER=Accept-Language:en-in",
        "PreSnapshot=webpage_1560325702433.png",
        "Snapshot=webpage_1560325705916.png",
        INLINE_URLS,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/sun_swede.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/flights.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/home.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/signoff.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/splash_Findflight.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/images/continue.gif", "HEADER=Accept-Language:en-in", END_INLINE
    );

    ns_end_transaction("banner_animated_gif", NS_AUTO_STATUS);

    //Page Auto splitted for Method = POST
    ns_start_transaction("query");
    ns_web_url ("query",
        "URL=https://clients1.google.com/tbproxy/af/query?client=Chromium",
        "METHOD=POST",
        "HEADER=Accept-Language:en-in",
        "HEADER=Content-Type:text/proto",
        "PreSnapshot=NA",
        "Snapshot=NA",
        BODY_BEGIN,
            "$CAVINCLUDE_NOPARAM$=http_request_body/query_main_url_1_1560325923487.body",
        BODY_END,
        INLINE_URLS,
            "URL=http://66.220.31.131:9020/tours/vep/images/velocigen.gif", "HEADER=Accept-Language:en-in", END_INLINE
    );

    ns_end_transaction("query", NS_AUTO_STATUS);
    ns_page_think_time(6.275);

    //Page Auto splitted for Image Link 'findFlights' Clicked by User
    ns_start_transaction("findflight_4");
    ns_web_url ("findflight_4",
        "URL=http://66.220.31.131:9020/cgi-bin/findflight?depart=Acapulco&departDate=06-13-2019&arrive=Acapulco&returnDate=06-14-2019&numPassengers=1&seatPref=None&seatType=Coach&findFlights.x=58&findFlights.y=14&findFlights=Submit",
        "HEADER=Upgrade-Insecure-Requests:1",
        "HEADER=Accept-Language:en-in",
        "PreSnapshot=webpage_1560325716857.png",
        "Snapshot=webpage_1560325730458.png",
        INLINE_URLS,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/banner_animated.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/sun_swede.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/flights.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/home.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/signoff.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/images/splash_Searchresults.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/images/continue.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/images/startover.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/vep/images/velocigen.gif", "HEADER=Accept-Language:en-in", END_INLINE
    );

    ns_end_transaction("findflight_4", NS_AUTO_STATUS);
    ns_page_think_time(13.571);

    //Page Auto splitted for Image Link 'reserveFlights' Clicked by User
    ns_start_transaction("findflight_5");
    ns_web_url ("findflight_5",
        "URL=http://66.220.31.131:9020/cgi-bin/findflight?hidden_outboundFlight_button0=000%7C0%7C06-13-2019&outboundFlight=button1&hidden_outboundFlight_button1=001%7C0%7C06-13-2019&hidden_outboundFlight_button2=002%7C0%7C06-13-2019&hidden_outboundFlight_button3=003%7C0%7C06-13-2019&numPassengers=1&advanceDiscount=&seatType=Coach&seatPref=None&reserveFlights.x=43&reserveFlights.y=14",
        "HEADER=Upgrade-Insecure-Requests:1",
        "HEADER=Accept-Language:en-in",
        "PreSnapshot=webpage_1560325738776.png",
        "Snapshot=webpage_1560325748692.png"
    );

    ns_end_transaction("findflight_5", NS_AUTO_STATUS);
    ns_page_think_time(0.016);

    //Page Auto splitted for Image Link 'reserveFlights' Clicked by User
    ns_start_transaction("banner_animated_gif_2");
    ns_web_url ("banner_animated_gif_2",
        "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/banner_animated.gif",
        "HEADER=Accept-Language:en-in",
        "PreSnapshot=webpage_1560325739020.png",
        "Snapshot=webpage_1560325743685.png",
        INLINE_URLS,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/sun_swede.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/flights.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/home.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/signoff.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/images/splash_creditcard.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/images/startover.gif", "HEADER=Accept-Language:en-in", END_INLINE
    );

    ns_end_transaction("banner_animated_gif_2", NS_AUTO_STATUS);

    //Page Auto splitted for Method = POST
    ns_start_transaction("query_2");
    ns_web_url ("query_2",
        "URL=https://clients1.google.com/tbproxy/af/query?client=Chromium",
        "METHOD=POST",
        "HEADER=Accept-Language:en-in",
        "HEADER=Content-Type:text/proto",
        "PreSnapshot=NA",
        "Snapshot=NA",
        BODY_BEGIN,
            "$CAVINCLUDE_NOPARAM$=http_request_body/query_2_main_url_1_1560325923595.body",
        BODY_END,
        INLINE_URLS,
            "URL=http://66.220.31.131:9020/tours/images/purchaseflight.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/vep/images/velocigen.gif", "HEADER=Accept-Language:en-in", END_INLINE
    );

    ns_end_transaction("query_2", NS_AUTO_STATUS);
    ns_page_think_time(7.51);

    //Page Auto splitted for Image Link 'buyFlights' Clicked by User
    ns_start_transaction("findflight_6");
    ns_web_url ("findflight_6",
        "URL=http://66.220.31.131:9020/cgi-bin/findflight?firstName=Tiger&lastName=Scott&address1=4261+Stevenson+Blvd.&address2=Fremont%2C+CA+94538&pass1=Scott+Tiger&creditCard=&expDate=&oldCCOption=&numPassengers=1&seatType=Coach&seatPref=None&outboundFlight=001%7C0%7C06-13-2019&advanceDiscount=&buyFlights.x=41&buyFlights.y=14&.cgifields=saveCC",
        "HEADER=Upgrade-Insecure-Requests:1",
        "HEADER=Accept-Language:en-in",
        "PreSnapshot=webpage_1560325754995.png",
        "Snapshot=webpage_1560325764135.png",
        INLINE_URLS,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/banner_animated.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/sun_swede.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/flights.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/home.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/signoff.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/images/splash_flightconfirm.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/images/bookanother.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/vep/images/velocigen.gif", "HEADER=Accept-Language:en-in", END_INLINE
    );

    ns_end_transaction("findflight_6", NS_AUTO_STATUS);
    ns_page_think_time(5.523);

    ns_start_transaction("reservation_3");
    ns_web_url ("reservation_3",
        "URL=http://66.220.31.131:9020/cgi-bin/reservation?BookAnother.x=49&BookAnother.y=12",
        "HEADER=Upgrade-Insecure-Requests:1",
        "HEADER=Accept-Language:en-in",
        "PreSnapshot=webpage_1560325769462.png",
        "Snapshot=webpage_1560325778602.png"
    );

    ns_end_transaction("reservation_3", NS_AUTO_STATUS);
    ns_page_think_time(0.048);

    //Page Auto splitted for Image Link 'BookAnother' Clicked by User
    ns_start_transaction("banner_animated_gif_3");
    ns_web_url ("banner_animated_gif_3",
        "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/banner_animated.gif",
        "HEADER=Accept-Language:en-in",
        "PreSnapshot=webpage_1560325769781.png",
        "Snapshot=webpage_1560325773533.png",
        INLINE_URLS,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/sun_swede.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/flights.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/home.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/signoff.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/splash_Findflight.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/images/continue.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/vep/images/velocigen.gif", "HEADER=Accept-Language:en-in", END_INLINE
    );

    ns_end_transaction("banner_animated_gif_3", NS_AUTO_STATUS);
    ns_page_think_time(2.585);

    ns_start_transaction("findflight_7");
    ns_web_url ("findflight_7",
        "URL=http://66.220.31.131:9020/cgi-bin/findflight?depart=Acapulco&departDate=06-13-2019&arrive=Acapulco&returnDate=06-14-2019&numPassengers=1&seatPref=None&seatType=Coach&findFlights.x=76&findFlights.y=5&findFlights=Submit",
        "HEADER=Upgrade-Insecure-Requests:1",
        "HEADER=Accept-Language:en-in",
        "PreSnapshot=webpage_1560325781171.png",
        "Snapshot=webpage_1560325790392.png"
    );

    ns_end_transaction("findflight_7", NS_AUTO_STATUS);
    ns_page_think_time(0.062);

    //Page Auto splitted for Image Link 'findFlights' Clicked by User
    ns_start_transaction("banner_animated_gif_4");
    ns_web_url ("banner_animated_gif_4",
        "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/banner_animated.gif",
        "HEADER=Accept-Language:en-in",
        "PreSnapshot=webpage_1560325781662.png",
        "Snapshot=webpage_1560325786290.png",
        INLINE_URLS,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/sun_swede.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/flights.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/home.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/signoff.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/images/splash_Searchresults.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/images/continue.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/images/startover.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/vep/images/velocigen.gif", "HEADER=Accept-Language:en-in", END_INLINE
    );

    ns_end_transaction("banner_animated_gif_4", NS_AUTO_STATUS);
    ns_page_think_time(2.458);

    ns_start_transaction("welcome_2");
    ns_web_url ("welcome_2",
        "URL=http://66.220.31.131:9020/cgi-bin/welcome",
        "HEADER=Upgrade-Insecure-Requests:1",
        "HEADER=Accept-Language:en-in",
        "PreSnapshot=webpage_1560325792739.png",
        "Snapshot=webpage_1560325799377.png"
    );

    ns_end_transaction("welcome_2", NS_AUTO_STATUS);
    ns_page_think_time(0.047);

    //Page Auto splitted for Image Link 'SignOff Button' Clicked by User
    ns_start_transaction("banner_animated_gif_5");
    ns_web_url ("banner_animated_gif_5",
        "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/banner_animated.gif",
        "HEADER=Accept-Language:en-in",
        "PreSnapshot=webpage_1560325793079.png",
        "Snapshot=webpage_1560325797705.png",
        INLINE_URLS,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/sun_swede.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/login.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/images/banner_merctur.jpg", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/vep/images/velocigen.gif", "HEADER=Accept-Language:en-in", END_INLINE
    );

    ns_end_transaction("banner_animated_gif_5", NS_AUTO_STATUS);
    ns_page_think_time(12.733);

    //Page Auto splitted for 
    ns_start_transaction("login_3");
    ns_web_url ("login_3",
        "URL=http://66.220.31.131:9020/cgi-bin/login?userSession=75893.0884568651DQADHfApHDHfcDtccpfAttcf&username=saja&password=abd&login.x=58&login.y=19&login=Login&JSFormSubmit=off",
        "HEADER=Upgrade-Insecure-Requests:1",
        "HEADER=Accept-Language:en-in",
        "PreSnapshot=webpage_1560325809477.png",
        "Snapshot=webpage_1560325818093.png"
    );

    ns_end_transaction("login_3", NS_AUTO_STATUS);
    ns_page_think_time(0.062);

    //Page Auto splitted for Image Link 'Login' Clicked by User
    ns_start_transaction("banner_animated_gif_6");
    ns_web_url ("banner_animated_gif_6",
        "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/banner_animated.gif",
        "HEADER=Accept-Language:en-in",
        "PreSnapshot=webpage_1560325809839.png",
        "Snapshot=webpage_1560325814629.png",
        INLINE_URLS,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/sun_swede.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/flights.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/home.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/signoff.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/images/banner_merctur.jpg", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/vep/images/velocigen.gif", "HEADER=Accept-Language:en-in", END_INLINE
    );

    ns_end_transaction("banner_animated_gif_6", NS_AUTO_STATUS);
    ns_page_think_time(11.144);

    ns_start_transaction("home");
    ns_web_url ("home",
        "URL=http://66.220.31.131:9020/cgi-bin/home",
        "HEADER=Upgrade-Insecure-Requests:1",
        "HEADER=Accept-Language:en-in",
        "PreSnapshot=webpage_1560325829161.png",
        "Snapshot=webpage_1560325836913.png"
    );

    ns_end_transaction("home", NS_AUTO_STATUS);
    ns_page_think_time(0.016);

    //Page Auto splitted for Image Link 'Home Button' Clicked by User
    ns_start_transaction("banner_animated_gif_7");
    ns_web_url ("banner_animated_gif_7",
        "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/banner_animated.gif",
        "HEADER=Accept-Language:en-in",
        "PreSnapshot=webpage_1560325829458.png",
        "Snapshot=webpage_1560325834554.png",
        INLINE_URLS,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/sun_swede.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/flights.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/home.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/signoff.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/images/banner_merctur.jpg", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/vep/images/velocigen.gif", "HEADER=Accept-Language:en-in", END_INLINE
    );

    ns_end_transaction("banner_animated_gif_7", NS_AUTO_STATUS);
    ns_page_think_time(2.064);

    ns_start_transaction("reservation_4");
    ns_web_url ("reservation_4",
        "URL=http://66.220.31.131:9020/cgi-bin/reservation",
        "HEADER=Upgrade-Insecure-Requests:1",
        "HEADER=Accept-Language:en-in",
        "PreSnapshot=webpage_1560325838922.png",
        "Snapshot=webpage_1560325847374.png"
    );

    ns_end_transaction("reservation_4", NS_AUTO_STATUS);
    ns_page_think_time(0.031);

    //Page Auto splitted for Image Link 'Search Flights Button' Clicked by User
    ns_start_transaction("banner_animated_gif_8");
    ns_web_url ("banner_animated_gif_8",
        "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/banner_animated.gif",
        "HEADER=Accept-Language:en-in",
        "PreSnapshot=webpage_1560325839226.png",
        "Snapshot=webpage_1560325843208.png",
        INLINE_URLS,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/sun_swede.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/flights.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/home.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/signoff.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/splash_Findflight.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/images/continue.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/vep/images/velocigen.gif", "HEADER=Accept-Language:en-in", END_INLINE
    );

    ns_end_transaction("banner_animated_gif_8", NS_AUTO_STATUS);
    ns_page_think_time(8.569);

    //Page Auto splitted for 
    ns_start_transaction("findflight_8");
    ns_web_url ("findflight_8",
        "URL=http://66.220.31.131:9020/cgi-bin/findflight?depart=Acapulco&departDate=06-13-2019&arrive=Acapulco&returnDate=06-14-2019&numPassengers=2&seatPref=Aisle&seatType=First&findFlights.x=75&findFlights.y=9&findFlights=Submit",
        "HEADER=Upgrade-Insecure-Requests:1",
        "HEADER=Accept-Language:en-in",
        "PreSnapshot=webpage_1560325855930.png",
        "Snapshot=webpage_1560325864206.png",
        INLINE_URLS,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/banner_animated.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/sun_swede.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/flights.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/home.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/signoff.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/images/splash_Searchresults.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/images/startover.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/images/continue.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/vep/images/velocigen.gif", "HEADER=Accept-Language:en-in", END_INLINE
    );

    ns_end_transaction("findflight_8", NS_AUTO_STATUS);
    ns_page_think_time(7.738);

    //Page Auto splitted for 
    ns_start_transaction("findflight_9");
    ns_web_url ("findflight_9",
        "URL=http://66.220.31.131:9020/cgi-bin/findflight?hidden_outboundFlight_button0=000%7C0%7C06-13-2019&outboundFlight=button1&hidden_outboundFlight_button1=001%7C0%7C06-13-2019&hidden_outboundFlight_button2=002%7C0%7C06-13-2019&hidden_outboundFlight_button3=003%7C0%7C06-13-2019&numPassengers=2&advanceDiscount=&seatType=First&seatPref=Aisle&reserveFlights.x=64&reserveFlights.y=17",
        "HEADER=Upgrade-Insecure-Requests:1",
        "HEADER=Accept-Language:en-in",
        "PreSnapshot=webpage_1560325871879.png",
        "Snapshot=webpage_1560325881098.png",
        INLINE_URLS,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/banner_animated.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/sun_swede.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/flights.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/home.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/signoff.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/images/startover.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/images/splash_creditcard.gif", "HEADER=Accept-Language:en-in", END_INLINE
    );

    ns_end_transaction("findflight_9", NS_AUTO_STATUS);

    //Page Auto splitted for Method = POST
    ns_start_transaction("query_3");
    ns_web_url ("query_3",
        "URL=https://clients1.google.com/tbproxy/af/query?client=Chromium",
        "METHOD=POST",
        "HEADER=Accept-Language:en-in",
        "HEADER=Content-Type:text/proto",
        "PreSnapshot=NA",
        "Snapshot=NA",
        BODY_BEGIN,
            "$CAVINCLUDE_NOPARAM$=http_request_body/query_3_main_url_1_1560325923830.body",
        BODY_END,
        INLINE_URLS,
            "URL=http://66.220.31.131:9020/tours/images/purchaseflight.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/vep/images/velocigen.gif", "HEADER=Accept-Language:en-in", END_INLINE
    );

    ns_end_transaction("query_3", NS_AUTO_STATUS);
    ns_page_think_time(11.917);

    //Page Auto splitted for Image Link 'buyFlights' Clicked by User
    ns_start_transaction("findflight_10");
    ns_web_url ("findflight_10",
        "URL=http://66.220.31.131:9020/cgi-bin/findflight?firstName=Tiger&lastName=Scott&address1=4261+Stevenson+Blvd.&address2=Fremont%2C+CA+94538&pass1=Scott+Tiger&pass2=&creditCard=121&expDate=&oldCCOption=&numPassengers=2&seatType=First&seatPref=Aisle&outboundFlight=001%7C0%7C06-13-2019&advanceDiscount=&buyFlights.x=66&buyFlights.y=16&.cgifields=saveCC",
        "HEADER=Upgrade-Insecure-Requests:1",
        "HEADER=Accept-Language:en-in",
        "PreSnapshot=webpage_1560325892707.png",
        "Snapshot=webpage_1560325902031.png",
        INLINE_URLS,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/banner_animated.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/sun_swede.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/flights.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/home.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/Merc10-dev/images/signoff.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/images/splash_flightconfirm.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/images/bookanother.gif", "HEADER=Accept-Language:en-in", END_INLINE,
            "URL=http://66.220.31.131:9020/tours/vep/images/velocigen.gif", "HEADER=Accept-Language:en-in", END_INLINE
    );

    ns_end_transaction("findflight_10", NS_AUTO_STATUS);
    ns_page_think_time(17.766);

}
