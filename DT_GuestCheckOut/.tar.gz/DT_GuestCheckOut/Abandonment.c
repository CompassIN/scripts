/*-----------------------------------------------------------------------------
    Name: Abandonment
    Recorded By: anjali
    Flow details:
    Modification History:  
-----------------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ns_string.h"
void Abandonment()
{
   

  	ns_exit_session();    		
}
