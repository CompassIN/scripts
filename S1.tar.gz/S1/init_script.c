/*-----------------------------------------------------------------------------
    Name: init_script
    Recorded By: netstorm
    Date of recording: 04/09/2012 07:04:09
    Flow details:
    Modification History:
-----------------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ns_string.h"

int init_script()
{
    return 0;
}
