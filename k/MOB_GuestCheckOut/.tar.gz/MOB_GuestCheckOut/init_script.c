/*-----------------------------------------------------------------------------
    Name: init_script
    Recorded By: anjali
    Date of recording: 06/27/2016 02:50:12
    Flow details:
    Build details: 4.1.4 (build# 43)
    Modification History:
-----------------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ns_string.h"

int init_script()
{
    return 0;
}
