/*-----------------------------------------------------------------------------
    Name:Abandonment
    Recorded By: anjali
    Date of recording: 06/29/2016 12:38:30
    Flow details:
    Build details: 4.1.4 (build# 43)
    Modification History:
-----------------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ns_string.h"

void Abandonment()
{
   ns_exit_session();
}
