/*-----------------------------------------------------------------------------
    Name: init_script
    Recorded By: abhishek
    Date of recording: 02/18/2017 12:55:21
    Flow details:
    Build details: 4.1.6 (build# 53)
    Modification History:
-----------------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ns_string.h"

int init_script()
{
    return 0;
}
