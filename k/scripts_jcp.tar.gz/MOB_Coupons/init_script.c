/*-----------------------------------------------------------------------------
    Name: init_script
    Recorded By: Kalyani
    Date of recording: 05/26/2016 06:07:24
    Flow details:
    Build details: 4.1.4 (build# 40)
    Modification History:
-----------------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ns_string.h"

int init_script()
{
    return 0;
}
