/*-----------------------------------------------------------------------------
    Name: exit_script
    Recorded By: anjali
    Date of recording: 04/28/2017 01:23:52
    Flow details:
    Build details: 4.1.6 (build# 56)
    Modification History:
-----------------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ns_string.h"

int exit_script()
{
    return 0;
}
