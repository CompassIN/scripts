/*-----------------------------------------------------------------------------
    Name: init_script
    Recorded By: Kalyani
    Date of recording: 07/25/2019 04:25:17
    Flow details:
    Build details: 4.1.14 (build# 126)
    Modification History:
-----------------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ns_string.h"

int init_script()
{
    return 0;
}
