/*-----------------------------------------------------------------------------
    Name: GoToNextAction
    Recorded By: Deepanshu
    Date of recording: 11/18/2014 01:59:44
    Flow details:
    Build details: 4.0.0 (build# 34)
    Modification History:
-----------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ns_string.h"
#include "Util.c"
void GoToNextAction()
{
   
    
}
