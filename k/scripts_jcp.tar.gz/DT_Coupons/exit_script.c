/*-----------------------------------------------------------------------------
    Name: exit_script
    Recorded By: Anjali
    Date of recording: 05/18/2016 03:31:48
    Flow details:
    Build details: 4.1.4 (build# 40)
    Modification History:
-----------------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ns_string.h"

int exit_script()
{
    return 0;
}
